from createdb import run
from test import test_run


if __name__ == "__main__":
    run()
    test_run()
